from flask import Flask, request
import logging
from prometheus_client import start_http_server, Counter

# OpenTelemetry Imports
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.instrumentation.flask import FlaskInstrumentor
from opentelemetry.instrumentation.logging import LoggingInstrumentor


class CustomFormatter(logging.Formatter):
    def format(self, record):
        # Get the current span context
        span = trace.get_current_span()
        if span and span.get_span_context().is_valid:
            ctx = span.get_span_context()
            record.trace_id = format(ctx.trace_id, '032x')  # Format trace_id as a 32-character hex string
        else:
            record.trace_id = "N/A"  # Use "N/A" when trace_id is not available

        # Now call the default formatter to handle the remaining formatting
        return super().format(record)


# Initialize Flask app
app = Flask(__name__)

# Set up logging
log_format = '%(asctime)s %(levelname)s [%(trace_id)s] %(message)s'
log_formatter = CustomFormatter(log_format)
log_handler = logging.FileHandler('/var/log/flask/flask_app.log')
log_handler.setFormatter(log_formatter)

logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(log_handler)

logger = logging.getLogger()
#log_format='%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s'
#logging.basicConfig(
#        filename='/var/log/flask/flask_app.log',
#        level=logging.INFO,
#        #format='%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s'
#        format=log_format
#        )


# OpenTelemetry configuration
#resource = Resource(attributes={
#    "service.name": "flask-app"
#})

# Set up Jaeger Exporter
#jaeger_exporter = JaegerExporter(
#    agent_host_name="localhost",
#    agent_port=6831,
#)

# Set up TracerProvider
#trace.set_tracer_provider(TracerProvider(resource=resource))
#tracer = trace.get_tracer(__name__)
#trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(jaeger_exporter))

trace.set_tracer_provider(TracerProvider(resource=Resource.create({"service.name": "flask-app"})))
jaeger_exporter = JaegerExporter(agent_host_name="localhost", agent_port=6831)
span_processor = BatchSpanProcessor(jaeger_exporter)
trace.get_tracer_provider().add_span_processor(span_processor)

# Instrument Flask and Logging
FlaskInstrumentor().instrument_app(app)
LoggingInstrumentor().instrument(set_logging_format=True)

# Start Prometheus metrics server on port 8000
start_http_server(8000)

# Define a Counter metric for Prometheus
REQUEST_COUNT = Counter('http_requests_total', 'Total number of HTTP requests')

# Define a route
@app.route('/hello')
def hello():
    name = request.args.get('name', 'World')
    app.logger.info(f'Received request with name: {name}')
    REQUEST_COUNT.inc()  # Increment the Counter metric
    return f'Hello, {name}!'

# Run Flask app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

